/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tpptransversal;

import Controladores.AlumnoData;
import Controladores.CursadaData;
import Controladores.MateriaData;
import Modelo.Alumno;
import Vistas.VistaCursada;
import java.time.LocalDate;
import java.time.Month;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author H
 */
public class TPpTransversal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AlumnoData AD = new AlumnoData();
        MateriaData MD = new MateriaData();
        CursadaData CD = new CursadaData();
        
        System.out.println("NOMBRE ALUMNO ID 3: "+ AD.buscarAlumno(3).Nombre);
        
        System.out.println("SE MUESTRA ARRAY CON ALUMNOS");
        
        for (Iterator iterator = AD.listarAlumnos().iterator(); iterator.hasNext();) {
            Object next = iterator.next();
            System.out.println(next.toString());
            
        }
        
//        System.out.println("ACTUALIZAR ESTADO ALUMNO");
//        int id;
//        
//        System.out.println("ELIJA ID ALUMNO");
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
//        id=leer.nextInt();
//        
//        System.out.println("1=ACTIVO - 0=BAJA");
//        boolean bl=false;
//        int i= leer.nextInt();
//        if(i==1){
//            bl=true;
//        }else if(i==0){
//        bl=false;
//    }
        System.out.println("ESTADO ALUMNO 3 A FALSE");
        AD.estadoAlumno(3, false);
        System.out.println("SE MUESTRA ALUMNO 3");
        System.out.println(AD.buscarAlumno(3).Estado);
        
        
        
            System.out.println("LISTA MATERIAS");
            for (Iterator iterator = MD.listarMaterias().iterator(); iterator.hasNext();) {
                Object next = iterator.next();
                System.out.println(next.toString());
            }   
            
            
            System.out.println("MATERIAS ALUMNO 2");
            for (Iterator iterator = CD.MateriasInscriptas_Alumno(1).iterator(); iterator.hasNext();) {
                Object next = iterator.next();
                System.out.println(next.toString());
            }
            
//            System.out.println("SE BORRA MATERIA 4 ALUMNO 1");
//            CD.bajaCursada(1, 4);
            
            
//            System.out.println("ACTUALIZAR NOTA ALUMNO");
//            System.out.println("ELIJA ID");
//            int is=leer.nextInt();
//            System.out.println("ID MATERIA:");
//            int mat=leer.nextInt();
//            System.out.println("INGRESE NOTA NUEVA");
//            Double nota=leer.nextDouble();
//            CD.actualizarNota(nota, is,mat);
//            
            System.out.println("PRUEBA GET ID ALUMNO");
            VistaCursada vc= new VistaCursada();
            System.out.println(vc.getIDalumno());
            System.out.println("PRUEBA GET ID MATERIA");
            vc.getIDmateria();
        }
    }
    

