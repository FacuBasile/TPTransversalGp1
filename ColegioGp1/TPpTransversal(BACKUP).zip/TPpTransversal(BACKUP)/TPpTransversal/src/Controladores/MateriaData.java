/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.sql.Connection;
import Modelo.Materia;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.Query;
import javax.swing.JOptionPane;
/**
 *
 * @author H
 */
public class MateriaData {
    private final Connection con;

    public MateriaData() {
        con = Conexion.getConexion();
    }
    
    
    public void nuevaMateria(Materia m){
        
        String Query;
        Query="INSERT INTO `materia`(`Nombre`, `Anio`, `Estado`) VALUES (?, ? , ?)";
        
        
        try{
            PreparedStatement stmt = con.prepareStatement(Query, Statement.RETURN_GENERATED_KEYS);
                      
            stmt.setString(1, m.Nombre);
            stmt.setInt(2, m.Anio);
            stmt.setBoolean(3, true);
                               
            int f = stmt.executeUpdate();          
            
            if(f == 1){
                JOptionPane.showMessageDialog(null, "MATERIA GUARDADA");
            } else {
                JOptionPane.showMessageDialog(null, "YA SE ENCUENTRA LA MATERIA");
            }
            stmt.close();
                             
        }catch (Exception e){
            
        }
        
    }
    
    public Materia buscarMateria(int idmateria){
        String query="SELECT * FROM `materia` WHERE materia.IdMateria = ?";
        
        Materia m = null;

        try{
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, idmateria);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()){
                m = new Materia(rs.getInt("IdMateria"),rs.getString("Nombre"),
                                        rs.getInt("Anio"),
                                        rs.getBoolean("Estado"));
            } else{
                JOptionPane.showMessageDialog(null, "NO SE ENCONTRÓ LA MATERIA");
            }
            
            stmt.close();
              
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "ERROR AL BUSCAR MATERIA");
        }
        
        
        return m;
    }
    
    public boolean existeMateria(String materia_nombre){
        boolean existe = false;
        String query="SELECT * FROM materia WHERE materia.Nombre LIKE ?";
        
        try{
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, materia_nombre);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()){
               existe = true;
            } 
            
            stmt.close();
            
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, "NO SE ENCONTRÓ LA MATERIA");
        }
        
        return existe;
    }
    
    public ArrayList<Materia> listarMaterias(){
        ArrayList<Materia> materias = new ArrayList();
        
        String query="SELECT * FROM materia";      
        
        try{
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()){
                Materia m = new Materia(rs.getInt("IdMateria"),rs.getString("Nombre"),
                                        rs.getInt("Anio"),
                                        rs.getBoolean("Estado"));
            materias.add(m);
            }
            
            stmt.close();
              
        }catch (Exception e){
             JOptionPane.showMessageDialog(null, "NO HAY MATERIAS");
        }
        return materias;
    }
    
    public void modificarMateria(String nombre, int anio, int idmateria){
        String update = "UPDATE `materia` SET `Nombre` = ?,`Anio`= ? WHERE IdMateria = ?";
        
        try {
            PreparedStatement stmt = con.prepareStatement(update);
            stmt.setString(1, nombre);
            stmt.setInt(2, anio);
            stmt.setInt(3, idmateria);       
            int fila = stmt.executeUpdate();
            
            if(fila == 1){            
                JOptionPane.showMessageDialog(null, "MATERIA MODIFICADA!!");
            } else {
                JOptionPane.showMessageDialog(null, "NO SE HALLÓ LA MATERIA A MODIFICAR");
            }
            stmt.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERROR INESPERADO!!");
        }
    }
    
    public void eliminarMateria(int idmateria, boolean estado){
        String query = "UPDATE `materia` SET `Estado` = ? WHERE IdMateria = ?";
        
        try {
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setBoolean(1, estado);  
            stmt.setInt(2, idmateria); 
            int fila = stmt.executeUpdate();
            
            if(fila == 1){                     
                JOptionPane.showMessageDialog(null, "SE DIÓ DE BAJA LA MATERIA");
            } else {
                JOptionPane.showMessageDialog(null, "NO SE ENCONTRÓ LA MATERIA");
            }
            
            stmt.close();
        } catch (SQLException sQLException) {
                JOptionPane.showMessageDialog(null, "ERROR AL ELIMINAR MATERIA");
        }
    }
}
