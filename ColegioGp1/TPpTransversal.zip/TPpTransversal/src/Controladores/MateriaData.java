/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import java.sql.Connection;
import Modelo.Materia;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.management.Query;
import javax.swing.JOptionPane;
/**
 *
 * @author H
 */
public class MateriaData {
    private final Connection con;

    public MateriaData() {
        con = Conexion.getConexion();
    }
    
    
    public void nuevaMateria(Materia m){
        
        String Query;
        Query="INSERT INTO `materia`(`IdMateria`, `Nombre`, `Anio`, `Estado`) VALUES ( ? , ?, ? , ?)";
        
        
        try{
            PreparedStatement stmt = con.prepareStatement(Query, Statement.RETURN_GENERATED_KEYS);
            
            stmt.setString(2, m.Nombre);
            stmt.setInt(3, m.Anio);
            stmt.setBoolean(4, true);
            
            
            stmt.executeUpdate();
            
            
            stmt.close();
            
            
        }catch (Exception e){
            
        }
        
    }
    
    public Materia buscarMateria(int idmateria){
        String query="SELECT * FROM `materia` WHERE materia.IdMateria = ?;";
        
        Materia m=null;
        
        
        try{
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()){
                m = new Materia(rs.getInt("IdMateria"),rs.getString("Nombre"),
                                        rs.getInt("Anio"),
                                        rs.getBoolean("Estado"));
            
            }
            
            stmt.close();
              
        }catch (Exception e){
            
        }
        
        
        return m;
    }
    
    public ArrayList<Materia> listarMaterias(){
        ArrayList<Materia> materias = new ArrayList();
        
        String query="SELECT * FROM Materia";
        
        
        try{
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()){
                Materia m = new Materia(rs.getInt("IdMateria"),rs.getString("Nombre"),
                                        rs.getInt("Anio"),
                                        rs.getBoolean("Estado"));
            materias.add(m);
            }
            
            stmt.close();
              
        }catch (Exception e){
            
        }
        return materias;
    }
}
