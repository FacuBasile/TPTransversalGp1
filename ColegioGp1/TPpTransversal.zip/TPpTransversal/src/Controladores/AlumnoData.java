/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Modelo.Alumno;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author H
 */
public class AlumnoData {
    private final Connection con;
    Alumno alumno;

    public AlumnoData() {
        con = Conexion.getConexion();
    }
    
    
    public void guardarAlumno(Alumno al){
        String Query = "INSERT INTO `alumno`(`Apellido`, `Nombre`, `DNI`, `FNacimiento`, `Estado`) VALUES (? , ? , ? , ? , ?)";
       
        
        
        try{
            
            
            PreparedStatement stmt = con.prepareStatement(Query, Statement.RETURN_GENERATED_KEYS);
            
            // reemplazar los ? del query guardado en el STATEMENT
            stmt.setString(1, al.getApellido());
            stmt.setString(2, al.getNombre());
            stmt.setInt(3, al.getDNI());
            stmt.setDate(4, Date.valueOf(al.getFNacimiento()));
            stmt.setBoolean(5, al.isEstado());
            
            //EJECUTAR COMANDO 
            stmt.executeUpdate();
            
            //GUARDAR CLAVE AUTOGENERADA PARA ID ALUMNO
            ResultSet resultado = stmt.getGeneratedKeys();
            
            //resultado.next() si se realizo la consulta y hay una key generada
            
            if(resultado.next()){
               
                
                JOptionPane.showMessageDialog(null, "ALUMNO AGREGADO");
               
            }
            stmt.close();
            
            
        } catch(SQLException e){
            JOptionPane.showMessageDialog(null, "ERROR AL AGREGAR ALUMNO: "+e.getMessage());
        }
        
        
        
    }
    
    public Alumno buscarAlumno(int id){
        Alumno alumnoBuscado = null;
        
        String query = "SELECT * FROM alumno WHERE IdAlumno = ? ";
        
        
        try{
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, id);
            
            
            //ejecutar codigo
            
            ResultSet rs = stmt.executeQuery();
            
            //recuperar datos de alumno desde el stmt
             if(rs.next()){
                 alumnoBuscado = new Alumno();
                 alumnoBuscado.setIdAlumno(rs.getInt("IdAlumno"));
                 alumnoBuscado.setApellido(rs.getString("Apellido"));
                 alumnoBuscado.setNombre(rs.getString("Nombre"));
                 alumnoBuscado.setDNI(rs.getInt(4));
                 alumnoBuscado.setFNacimiento(LocalDate.parse(rs.getDate(5).toString()));
                 
                 
             }
             stmt.close();
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "ALUMNO NO ENCONTRADO");
        }
        
        
        return alumnoBuscado;
    }
    
    public ArrayList<Alumno> listarAlumnos(){
        Alumno a;
        ArrayList <Alumno> alumnos = new ArrayList();
        
        try{
            String query = "SELECT Nombre,Apellido,DNI,IdAlumno FROM alumno";
        
        
        
            PreparedStatement stmt = con.prepareStatement(query);
            
            
            
            //ejecutar codigo
            
            ResultSet rs = stmt.executeQuery();
            
            //recuperar datos de alumno desde el stmt
            while(rs.next()){
                
                 a = new Alumno();
                 a.setIdAlumno(rs.getInt("IdAlumno"));
                 a.setApellido(rs.getString("Apellido"));
                 a.setNombre(rs.getString("Nombre"));
                 a.setDNI(rs.getInt("DNI"));
                 
                 alumnos.add(a);
             }
             stmt.close();
            
          
        }catch(Exception e){
            System.out.println("EXCEPTION DEVUELTA");
        }
        
        
        
        
        return alumnos;
        
    }
    
    public void estadoAlumno(int id,boolean bool){
        
        String query = "UPDATE alumno SET Estado= ? WHERE alumno.IdAlumno= ?";
        
        try{
            
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(2, id);
            stmt.setBoolean(1, bool);
            int res = stmt.executeUpdate();
            
            if(res==1){
                JOptionPane.showMessageDialog(null, "ESTADO DE ALUMNO ACTUALIZADO");
            }else if (res==0){
                JOptionPane.showMessageDialog(null, "NO SE PUDO ACTUALIZAR ALUMNO");
            }
            stmt.close();
            
            
            
            
        }catch(Exception e){
            System.out.println("SE DEVOLVIO UNA EXCEPCION");
        }
        
        
        
    }
            
    
    
}
