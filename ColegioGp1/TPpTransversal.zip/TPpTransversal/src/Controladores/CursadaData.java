/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controladores;

import Modelo.Alumno;
import Modelo.Cursada;
import Modelo.Materia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author H
 */
public class CursadaData {
    private final Connection con;

   
    public CursadaData(){
     con = Conexion.getConexion();
    }
   
    public void inscribirAlumno(int idMateria,int idAlumno,int nota){
        
        String query;
        
        query="INSERT INTO cursada (Alumno, Materia, Nota) VALUES (? , ? , ?) ";
        
                
                try{
                    PreparedStatement stmt = con.prepareStatement(query);
                    stmt.setInt(1, idAlumno);
                    stmt.setInt(2, idMateria);
                    stmt.setInt(3, nota);
                }catch (SQLException ex){
                    Logger.getLogger(CursadaData.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    
    public void actualizarNota(double nota,int idAlumno,int idMateria){
        
        String query;
        
        query="UPDATE `cursada` SET Nota= ? WHERE Alumno= ? AND Materia = ?";
        try {
            PreparedStatement stmt =con.prepareStatement(query);
            stmt.setDouble(1, nota);
            stmt.setInt(2, idAlumno);
            stmt.setInt(3, idMateria);
            
            stmt.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(CursadaData.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
               
    }
    
    public int notaAlumno(int al,int mat){
        int nota=0;
        String query;
        query="SELECT Alumno.Nombre, cursada.Materia, cursada.Nota FROM `cursada` INNER JOIN `alumno`\n"
                + " ON cursada.Alumno = Alumno.IdAlumno WHERE Alumno.IdAlumno = ? AND cursada.Materia= ?;";
        
        try {
            PreparedStatement stmt =con.prepareStatement(query);
            stmt.setInt(1, al);
            stmt.setInt(2, mat);
            
            ResultSet rs = stmt.executeQuery();
            
            if(rs.next()){
               nota=rs.getInt("Nota");
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(CursadaData.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            return nota;
    }
    
    public ArrayList<Materia> MateriasInscriptas_Alumno(int idAlumno){
        
        ArrayList<Materia> materias = new ArrayList();
        String query = "SELECT materia.* FROM cursada JOIN materia ON (cursada.Materia = materia.IdMateria) WHERE alumno = ?";
        
        try {
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, idAlumno);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Materia m = new Materia(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getBoolean(4));
                materias.add(m);
            }                     
        } catch (SQLException ex) {
            Logger.getLogger(CursadaData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return materias;
    }
    
    public ArrayList<Materia> MateriasNoInscriptas_Alumno(int idAlumno){
        
        ArrayList<Materia> materias = new ArrayList();
        String query = "SELECT materia.* FROM cursada JOIN materia ON (cursada.Materia = materia.IdMateria) WHERE alumno != ?";
        
        try {
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, idAlumno);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Materia m = new Materia(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getBoolean(4));
                materias.add(m);
            }                     
        } catch (SQLException ex) {
            Logger.getLogger(CursadaData.class.getName()).log(Level.SEVERE, null, ex);
        }
        return materias;
    }
    
    public List<Cursada> obtenerCursadas(){
        List<Cursada> cursadas = new ArrayList<>();
         
        
         
         AlumnoData ad = new AlumnoData();
         MateriaData md = new MateriaData();
        try {
            String sql = "SELECT * FROM Cursada;";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                Cursada insc = new Cursada();
                insc.setIdMesa(rs.getInt("idInscripto"));
                
                //a travez del id se crea un alumno y se guarda en java en atributo alumno
                Alumno a = new Alumno(ad.buscarAlumno(rs.getInt("IdAlumno")).IdAlumno,   // int id
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).DNI,      //int dni
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).Nombre,     //String nombre
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).Apellido,    //String Apellido        
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).FNacimiento,    //LocalDate fNacimiento
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).Estado); // Boolean estado
                
                
                insc.setAlumno(a);  // se guarda el alumno creado en el atributo alumno 
                
                
                //a travez del id materia se crea una materia y se le asigna al atributo materia
                Materia m = new Materia(md.buscarMateria(rs.getInt("IdMateria")).IdMateria,
                                        md.buscarMateria(rs.getInt("IdMateria")).Nombre,
                                        md.buscarMateria(rs.getInt("IdMateria")).Anio,
                                        md.buscarMateria(rs.getInt("IdMateria")).Estado);
                
                insc.setMateria(m);
                
                // SETEO LA NOTA EN LA CLASE CURSADA LEYENDO LA COLUMNA "NOTA" EN SQL
                insc.setNota(rs.getDouble("Nota"));
                
                
                cursadas.add(insc);
            }      
            ps.close();
            
            
        }catch (SQLException ex) {
            JOptionPane.showInternalMessageDialog(null, "Error Inscripcion "+ex.getMessage());
        }
        return cursadas;
    }
    
    public List<Cursada> ObtenerCursadasAlumno(int idAlu){
        ArrayList<Cursada> cursadas = new ArrayList();
        Cursada insc = new Cursada();
        AlumnoData ad = new AlumnoData();
        MateriaData md = new MateriaData();
        try {
            
            String sql = "SELECT * FROM Cursada WHERE Alumno= ?";
            
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idAlu);
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                
                insc.setIdMesa(rs.getInt("idInscripto"));
                
                //a travez del id se crea un alumno y se guarda en java en atributo alumno
                Alumno a = new Alumno(ad.buscarAlumno(rs.getInt("IdAlumno")).IdAlumno,   // int id
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).DNI,      //int dni
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).Nombre,     //String nombre
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).Apellido,    //String Apellido        
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).FNacimiento,    //LocalDate fNacimiento
                                      ad.buscarAlumno(rs.getInt("IdAlumno")).Estado); // Boolean estado
                
                
                insc.setAlumno(a);  // se guarda el alumno creado en el atributo alumno 
                
                
                //a travez del id materia se crea una materia y se le asigna al atributo materia
                Materia m = new Materia(md.buscarMateria(rs.getInt("IdMateria")).IdMateria,
                                        md.buscarMateria(rs.getInt("IdMateria")).Nombre,
                                        md.buscarMateria(rs.getInt("IdMateria")).Anio,
                                        md.buscarMateria(rs.getInt("IdMateria")).Estado);
                
                insc.setMateria(m);
                
                // SETEO LA NOTA EN LA CLASE CURSADA LEYENDO LA COLUMNA "NOTA" EN SQL
                insc.setNota(rs.getDouble("Nota"));
                
                
                cursadas.add(insc);
            }      
            ps.close();
            
            
        }catch (SQLException ex) {
            JOptionPane.showInternalMessageDialog(null, "Error Inscripcion "+ex.getMessage());
        }
        
        return cursadas;
    }
    
    public List<Alumno> obtenerAlumnosDeMateria (int IdMateria){
        ArrayList<Alumno> alumnos = new ArrayList();
        AlumnoData ad = new AlumnoData();
        Alumno a ;
        String query;
        
        query ="SELECT * FROM `cursada` JOIN Alumno ON (cursada.Alumno=Alumno.IdAlumno) WHERE Materia = ?";
        
        try {
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, IdMateria);
            
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                 a = new Alumno(ad.buscarAlumno(rs.getInt("IdAlumno")).IdAlumno,   // int id
                                ad.buscarAlumno(rs.getInt("IdAlumno")).DNI,      //int dni
                                ad.buscarAlumno(rs.getInt("IdAlumno")).Nombre,     //String nombre
                                ad.buscarAlumno(rs.getInt("IdAlumno")).Apellido,    //String Apellido        
                                ad.buscarAlumno(rs.getInt("IdAlumno")).FNacimiento,    //LocalDate fNacimiento
                                ad.buscarAlumno(rs.getInt("IdAlumno")).Estado); // Boolean estado
                
                alumnos.add(a);
            }
            
            stmt.close();
            
        } catch (SQLException ex) {
            Logger.getLogger(CursadaData.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
        
        
        return alumnos;
    }
    
    public void bajaCursada(int idAlumno, int idMateria){
        String query;
        query="DELETE FROM `cursada` WHERE alumno= ? AND materia = ?";
        
        try {
            
            
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, idAlumno);
            stmt.setInt(2, idMateria);
            
            int i =stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "SE BORRARON "+i+" CURSADAS");
            
        } catch (SQLException ex) {
            Logger.getLogger(CursadaData.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //SENTENCIA QUE SE PUEDE USAR PARA VER MATERIAS A LAS QUE NO ESTA INSCRIPTO UN ALUMNO
   //"SELECT Alumno.Nombre, cursada.Materia, cursada.Nota FROM `cursada` INNER JOIN `alumno` ON cursada.Alumno = Alumno.IdAlumno WHERE Alumno.IdAlumno = ? AND cursada.Materia= ?;";
    
    
//    public ArrayList<Materia> materiasAInscribir(int idAlumno, int idMateria){
//        ArrayList<Materia> materias;
//        String query;
//        
//        query=
//        
//        
//    }
    
//    public List<Inscripcion> obtenerInscripciones(){
//        List<Inscripcion> cursadas = new ArrayList<>();
//          
//        try {
//            String sql = "SELECT * FROM inscripcion;";
//            PreparedStatement ps = con.prepareStatement(sql);
//            ResultSet rs = ps.executeQuery();
//            Inscripcion insc;
//            
//            while(rs.next()){
//                insc = new Inscripcion();
//                insc.setIdInscripcion(rs.getInt("idInscripto"));
//                
//                Alumno a = aluData.buscarAlumno(rs.getInt("idAlumno"));
//                insc.setIdAlumno(a.getIdAlumno());
//                
//                Materia m = matData.buscarMateria(rs.getInt("idMateria"));
//                insc.setIdMateria(m.getIdMateria());
//                insc.setNota(rs.getDouble("nota"));
//
//                cursadas.add(insc);
//            }      
//            ps.close();
//        }catch (SQLException ex) {
//            JOptionPane.showInternalMessageDialog(null, "Error Inscripcion "+ex.getMessage());
//        }
//        return cursadas;
//    }
}
